/*
 * Public API Surface of ngx-wheel
 */

export * from './lib/ngx-wheel.component';
export * from './lib/ngx-wheel.module';
